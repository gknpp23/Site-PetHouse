This "Animals Vector Isometric Icons" icon pack was downloaded from https://www.reshot.com/free-svg-icons/pack/animals-vector-isometric-icons-K27BCYWTJ5/ 

Please check the Reshot Icons license available at https://www.reshot.com/license/